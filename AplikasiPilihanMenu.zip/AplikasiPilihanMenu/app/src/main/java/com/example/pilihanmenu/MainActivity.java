package com.example.pilihanmenu;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recMenu;
    private ArrayList<Menu> listMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recMenu = findViewById(R.id.rec_listmenu);
        initData();

        recMenu.setAdapter(new MenuAdapter(listMenu));
        recMenu.setLayoutManager(new LinearLayoutManager(this));

    }

    private void initData(){
        this.listMenu = new ArrayList<>();
        listMenu.add(new Menu("Chicken Steak","Daging ayam dengan bumbu khas"
                ,80000F,R.drawable.chicken,true));
        listMenu.add(new Menu("Beef Steak","Daging sapi dengan cita rasa yang khas"
                ,120000F,R.drawable.beef,true));
        listMenu.add(new Menu("Tenderloin Steak","Daging dengan cara masak yang penuh teknik"
                ,150000F,R.drawable.tenderloin,true));
        listMenu.add(new Menu("Sirloin Steak","Daging dengan sentuhan chef handal"
                ,150000F,R.drawable.sirloin,true));
        listMenu.add(new Menu("Cordon Blue","Daging dengan teknik masak yang autentik"
                ,90000F,R.drawable.cordon,true));
        listMenu.add(new Menu("Es Teh","Es Teh manis/tawar"
                ,15000F,R.drawable.es_teh,true));
        listMenu.add(new Menu("Es Jeruk","Es/panas jeruk"
                ,20000F,R.drawable.es_jeruk,true));
        listMenu.add(new Menu("Milk Shake","Es/panas"
                ,30000F,R.drawable.milkshake,true));
    }



}